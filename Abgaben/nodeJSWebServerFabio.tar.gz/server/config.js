module.exports = {
  expressConfig: {
    PORT: 5000
  },

  mysqlConfig: {
    host: "sae.cuw2bz4mkgfb.eu-central-1.rds.amazonaws.com", //localhost
    user: "root",
    password: "11100111", //11100111
    database: "clientServerApp", //webApp
    port: 3306
  }
};
