module.exports = {
  dances: {
    latein: ["Rumba", "Salsa", "Samba", "Jive"],
    standard: ["Waltzer", "Langsamer Waltzer", "Quickstep", "Slowfox", "Tango"],
    misc: ["Tango Argentino"]
  },
  tags: ["schnell", "langsam", "traditionell", "modern"]
};
